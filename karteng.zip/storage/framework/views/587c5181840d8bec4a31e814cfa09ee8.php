<?php
    $navLogo = data_get($profile ?? null, 'logo');
?>
<header id="main-nav" class="nu-nav">
    <div class="nu-nav-inner">
        <!-- Brand -->
        <a href="<?php echo e(route('home')); ?>" class="nu-brand" aria-label="<?php echo e(config('app.name', 'NU Ranting')); ?>">
            <span class="nu-brand-logo">
                <?php if($navLogo): ?>
                    <img src="<?php echo e(asset('storage/' . $navLogo)); ?>" alt="Logo NU">
                <?php else: ?>
                    <i class="fas fa-star-and-crescent"></i>
                <?php endif; ?>
            </span>
            <span class="nu-brand-text">Sistem Informasi<br>Nahdlatul Ulama</span>
        </a>

        <!-- Desktop links -->
        <nav class="nu-links" aria-label="Navigasi utama">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Beranda</a>
            <a href="<?php echo e(route('profil')); ?>" class="<?php echo e(request()->routeIs('profil') ? 'active' : ''); ?>">Profil</a>
            <a href="<?php echo e(route('banom.index')); ?>" class="<?php echo e(request()->routeIs('banom.*') ? 'active' : ''); ?>">Banom</a>
            <a href="<?php echo e(route('anggota.index')); ?>" class="<?php echo e(request()->routeIs('anggota.*') ? 'active' : ''); ?>">Anggota</a>
            <a href="<?php echo e(route('berita.index')); ?>" class="<?php echo e(request()->routeIs('berita.*') ? 'active' : ''); ?>">Berita</a>
            <a href="<?php echo e(route('agenda.index')); ?>" class="<?php echo e(request()->routeIs('agenda.*') ? 'active' : ''); ?>">Agenda</a>
            <a href="<?php echo e(route('galeri.index')); ?>" class="<?php echo e(request()->routeIs('galeri.*') ? 'active' : ''); ?>">Galeri</a>
            <a href="<?php echo e(route('donasi.index')); ?>" class="two-line <?php echo e(request()->routeIs('donasi.*') ? 'active' : ''); ?>">Infaq /<br>Donasi</a>
        </nav>

        <!-- Actions -->
        <div class="nu-actions">
            <a href="<?php echo e(route('daftar-anggota')); ?>" class="nu-btn-join">
                <i class="fas fa-users"></i>
                <span>Daftar<br>Anggota</span>
            </a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nu-login">
                    <i class="fas fa-gauge"></i>
                    <span>Dashboard<br>Admin</span>
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="nu-login">
                    <i class="fas fa-user"></i>
                    <span>Login<br>Pengurus</span>
                </a>
            <?php endif; ?>
        </div>

        <!-- Burger -->
        <button type="button" id="mobile-menu-btn" class="nu-burger" aria-label="Buka menu" aria-expanded="false" aria-controls="mobile-menu">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- Mobile menu -->
    <div id="mobile-menu" class="nu-mobile">
        <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>"><i class="fas fa-house"></i> Beranda</a>
        <a href="<?php echo e(route('profil')); ?>" class="<?php echo e(request()->routeIs('profil') ? 'active' : ''); ?>"><i class="fas fa-landmark"></i> Profil Organisasi</a>
        <a href="<?php echo e(route('banom.index')); ?>" class="<?php echo e(request()->routeIs('banom.*') ? 'active' : ''); ?>"><i class="fas fa-sitemap"></i> Badan Otonom (Banom)</a>
        <a href="<?php echo e(route('anggota.index')); ?>" class="<?php echo e(request()->routeIs('anggota.*') ? 'active' : ''); ?>"><i class="fas fa-users"></i> Direktori Anggota</a>
        <a href="<?php echo e(route('berita.index')); ?>" class="<?php echo e(request()->routeIs('berita.*') ? 'active' : ''); ?>"><i class="fas fa-newspaper"></i> Warta &amp; Berita</a>
        <a href="<?php echo e(route('agenda.index')); ?>" class="<?php echo e(request()->routeIs('agenda.*') ? 'active' : ''); ?>"><i class="fas fa-calendar-days"></i> Agenda Kegiatan</a>
        <a href="<?php echo e(route('galeri.index')); ?>" class="<?php echo e(request()->routeIs('galeri.*') ? 'active' : ''); ?>"><i class="fas fa-images"></i> Galeri Dokumentasi</a>
        <a href="<?php echo e(route('donasi.index')); ?>" class="<?php echo e(request()->routeIs('donasi.*') ? 'active' : ''); ?>"><i class="fas fa-hand-holding-heart"></i> Infaq &amp; Donasi</a>

        <div class="nu-mobile-cta">
            <a href="<?php echo e(route('daftar-anggota')); ?>" class="primary"><i class="fas fa-id-card"></i> Daftar Anggota Baru</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-gauge"></i> Masuk Panel Admin</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>"><i class="fas fa-user"></i> Login Pengurus</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<div id="nu-progress" class="nu-progress" aria-hidden="true"></div>
<div class="nu-nav-spacer"></div>
<?php /**PATH /storage/emulated/0/Documents/Projects/karteng/resources/views/components/navbar.blade.php ENDPATH**/ ?>